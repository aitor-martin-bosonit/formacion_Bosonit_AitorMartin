package com.example.block11uploaddownloadfiles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Block11uploaddownloadfilesApplication {

	public static void main(String[] args) {
		SpringApplication.run(Block11uploaddownloadfilesApplication.class, args);
	}

}
