package com.example.block11uploaddownloadfiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Block11uploaddownloadfilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
